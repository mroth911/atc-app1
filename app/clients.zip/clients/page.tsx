"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";

type Category = "PCA" | "HM" | "CP" | "Other";

type Client = {
  clientId: string;
  firstName: string;
  lastName: string;
  category: Category;

  address: {
    home: string;
    street: string;
    apt: string;
    town: string;
    state: string;
    zip: string;
    phone: string;
    dob: string;
    gender: "M" | "F" | "X" | "";
  };

  hoursPerWeek: {
    homemaker: number;
    companion: number;
    appointment: number;
    chores: number;
    liveIn: number;
  };

  hoursPerMonth: {
    monthly: number;
    biWeekly: number;
    medical: number;
    oneTimeJan: number;
    oneTimeDec: number;
  };

  programBuckets: {
    cp: number;
    hm: number;
    pcaWeekly: number;
    pcaMonthly: number;
    pcaBiWeekly: number;
    adcDays: number;
  };

  rates: {
    hourly: number;
    overnight: number;
    perDiem: number;
    sub: number;
  };

  fosterPerWeek: {
    fca1: number;
    fca2: number;
    fca3: number;
    fca4: number;
    fcaVn: number;
  };

  respitePerWeek: {
    homemaker: number;
    companion: number;
    pca: number;
    pca12: number;
    pca24: number;
  };

  notes: string;
  hoursNotes: string;
};

const towns = ["BERLIN", "BRISTOL", "PLAINVILLE", "TERRYVILLE", "WATERBURY", "WOLCOTT"];
const categories: Category[] = ["PCA", "HM", "CP", "Other"];

const tabs = [
  "Address",
  "CCCI",
  "Assigned Hours",
  "Assigned Extra Hours",
  "Weekly Services",
  "Monthly Services",
  "Monthly Hours Used",
  "Vacations",
  "Narratives",
  "Service Orders",
  "Provider Report",
  "Appointments, T/S",
  "Reminders",
] as const;

type Tab = (typeof tabs)[number];

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <div className="text-xs font-medium text-slate-600">{children}</div>;
}

function Input({
  value,
  onChange,
  placeholder,
  type = "text",
  disabled,
}: {
  value: string | number;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: React.HTMLInputTypeAttribute;
  disabled?: boolean;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      type={type}
      disabled={disabled}
      className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-200 disabled:bg-slate-50"
    />
  );
}

function NumInput({
  value,
  onChange,
  min = 0,
  step = 1,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  step?: number;
}) {
  return (
    <input
      value={Number.isFinite(value) ? value : 0}
      onChange={(e) => onChange(Number(e.target.value || 0))}
      type="number"
      min={min}
      step={step}
      className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-200"
    />
  );
}

function Card({
  title,
  children,
  right,
}: {
  title: string;
  children: React.ReactNode;
  right?: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl bg-white ring-1 ring-slate-200">
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
        <div className="text-sm font-semibold text-slate-900">{title}</div>
        {right}
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

function ActionButton({
  label,
  onClick,
  tone = "default",
}: {
  label: string;
  onClick: () => void;
  tone?: "default" | "primary" | "danger";
}) {
  const cls =
    tone === "primary"
      ? "bg-emerald-600 text-white hover:bg-emerald-700"
      : tone === "danger"
      ? "bg-rose-600 text-white hover:bg-rose-700"
      : "bg-white text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50";
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-10 rounded-xl px-4 text-sm font-semibold transition ${cls}`}
    >
      {label}
    </button>
  );
}

export default function ClientsPage() {
  const [activeTab, setActiveTab] = useState<Tab>("Address");

  const [client, setClient] = useState<Client>({
    clientId: "0000000000",
    firstName: "RUTH",
    lastName: "ABAIR",
    category: "PCA",
    address: {
      home: "34",
      street: "MURLA RD",
      apt: "",
      town: "BERLIN",
      state: "CT",
      zip: "06037",
      phone: "8608284085",
      dob: "1934-11-09",
      gender: "F",
    },
    hoursPerWeek: { homemaker: 0, companion: 0, appointment: 0, chores: 0, liveIn: 0 },
    hoursPerMonth: { monthly: 0, biWeekly: 0, medical: 0, oneTimeJan: 0, oneTimeDec: 0 },
    programBuckets: { cp: 0, hm: 0, pcaWeekly: 0, pcaMonthly: 0, pcaBiWeekly: 0, adcDays: 0 },
    rates: { hourly: 0, overnight: 0, perDiem: 0, sub: 0 },
    fosterPerWeek: { fca1: 0, fca2: 0, fca3: 0, fca4: 0, fcaVn: 0 },
    respitePerWeek: { homemaker: 0, companion: 0, pca: 0, pca12: 0, pca24: 0 },
    notes: "",
    hoursNotes: "",
  });

  const totals = useMemo(() => {
    const weekTotal =
      client.hoursPerWeek.homemaker +
      client.hoursPerWeek.companion +
      client.hoursPerWeek.appointment +
      client.hoursPerWeek.chores +
      client.hoursPerWeek.liveIn;

    const monthTotal =
      client.hoursPerMonth.monthly +
      client.hoursPerMonth.biWeekly +
      client.hoursPerMonth.medical +
      client.hoursPerMonth.oneTimeJan +
      client.hoursPerMonth.oneTimeDec;

    return { weekTotal, monthTotal };
  }, [client]);

  function set<K extends keyof Client>(key: K, value: Client[K]) {
    setClient((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="sticky top-0 z-20 border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 py-4">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div className="min-w-0">
              <div className="flex items-center gap-3">
                <Link href="/" className="text-sm font-semibold text-slate-600 hover:text-slate-900">
                  â† Switchboard
                </Link>
                <span className="text-slate-300">/</span>
                <span className="text-sm font-semibold text-slate-900">Client</span>
              </div>
              <h1 className="mt-2 truncate text-2xl font-semibold tracking-tight text-slate-900">
                {client.lastName}, {client.firstName}
              </h1>
              <div className="mt-1 text-sm text-slate-600">
                Client ID: <span className="font-medium text-slate-900">{client.clientId}</span> â€¢ Category:{" "}
                <span className="font-medium text-slate-900">{client.category}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <ActionButton label="Save" tone="primary" onClick={() => alert("Save (wire to API later)")} />
              <ActionButton label="Appointments" onClick={() => alert("Open appointments (route later)")} />
              <ActionButton label="Find Employee" onClick={() => alert("Find employee (route later)")} />
              <ActionButton label="Exit" tone="danger" onClick={() => alert("Exit / sign out")} />
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="grid gap-4 lg:grid-cols-[360px_1fr]">
          <div className="space-y-4">
            <Card title="Client Identity">
              <div className="grid gap-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <FieldLabel>Client ID</FieldLabel>
                    <Input value={client.clientId} onChange={(v) => set("clientId", v)} placeholder="Client ID" />
                  </div>
                  <div>
                    <FieldLabel>Category</FieldLabel>
                    <select
                      value={client.category}
                      onChange={(e) => set("category", e.target.value as Category)}
                      className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-200"
                    >
                      {categories.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <FieldLabel>First Name</FieldLabel>
                    <Input value={client.firstName} onChange={(v) => set("firstName", v)} />
                  </div>
                  <div>
                    <FieldLabel>Last Name</FieldLabel>
                    <Input value={client.lastName} onChange={(v) => set("lastName", v)} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <FieldLabel>DOB</FieldLabel>
                    <Input
                      value={client.address.dob}
                      onChange={(v) => set("address", { ...client.address, dob: v })}
                      type="date"
                    />
                  </div>
                  <div>
                    <FieldLabel>Gender</FieldLabel>
                    <select
                      value={client.address.gender}
                      onChange={(e) => set("address", { ...client.address, gender: e.target.value as any })}
                      className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-200"
                    >
                      <option value="">â€”</option>
                      <option value="F">F</option>
                      <option value="M">M</option>
                      <option value="X">X</option>
                    </select>
                  </div>
                </div>
              </div>
            </Card>

            <Card title="Address">
              <div className="grid gap-3">
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <FieldLabel>Home</FieldLabel>
                    <Input value={client.address.home} onChange={(v) => set("address", { ...client.address, home: v })} />
                  </div>
                  <div className="col-span-2">
                    <FieldLabel>Street</FieldLabel>
                    <Input
                      value={client.address.street}
                      onChange={(v) => set("address", { ...client.address, street: v })}
                    />
                  </div>
                </div>

                <div>
                  <FieldLabel>Apt</FieldLabel>
                  <Input value={client.address.apt} onChange={(v) => set("address", { ...client.address, apt: v })} />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <FieldLabel>Town</FieldLabel>
                    <select
                      value={client.address.town}
                      onChange={(e) => set("address", { ...client.address, town: e.target.value })}
                      className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-200"
                    >
                      {towns.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <FieldLabel>State</FieldLabel>
                    <Input value={client.address.state} onChange={(v) => set("address", { ...client.address, state: v })} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <FieldLabel>Zip</FieldLabel>
                    <Input value={client.address.zip} onChange={(v) => set("address", { ...client.address, zip: v })} />
                  </div>
                  <div>
                    <FieldLabel>Phone</FieldLabel>
                    <Input value={client.address.phone} onChange={(v) => set("address", { ...client.address, phone: v })} />
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <div className="space-y-4">
            <div className="grid gap-4 xl:grid-cols-3">
              <Card
                title="Hours per Week"
                right={
                  <div className="text-xs font-semibold text-slate-600">
                    Total: <span className="text-slate-900">{totals.weekTotal}</span>
                  </div>
                }
              >
                <div className="grid gap-3">
                  <Row label="Homemaker">
                    <NumInput value={client.hoursPerWeek.homemaker} onChange={(n) => set("hoursPerWeek", { ...client.hoursPerWeek, homemaker: n })} />
                  </Row>
                  <Row label="Companion">
                    <NumInput value={client.hoursPerWeek.companion} onChange={(n) => set("hoursPerWeek", { ...client.hoursPerWeek, companion: n })} />
                  </Row>
                  <Row label="Appointment">
                    <NumInput value={client.hoursPerWeek.appointment} onChange={(n) => set("hoursPerWeek", { ...client.hoursPerWeek, appointment: n })} />
                  </Row>
                  <Row label="Chores">
                    <NumInput value={client.hoursPerWeek.chores} onChange={(n) => set("hoursPerWeek", { ...client.hoursPerWeek, chores: n })} />
                  </Row>
                  <Row label="Live-In">
                    <NumInput value={client.hoursPerWeek.liveIn} onChange={(n) => set("hoursPerWeek", { ...client.hoursPerWeek, liveIn: n })} />
                  </Row>
                </div>
              </Card>

              <Card
                title="Hours per Month"
                right={
                  <div className="text-xs font-semibold text-slate-600">
                    Total: <span className="text-slate-900">{totals.monthTotal}</span>
                  </div>
                }
              >
                <div className="grid gap-3">
                  <Row label="Monthly">
                    <NumInput value={client.hoursPerMonth.monthly} onChange={(n) => set("hoursPerMonth", { ...client.hoursPerMonth, monthly: n })} />
                  </Row>
                  <Row label="BiWeekly">
                    <NumInput value={client.hoursPerMonth.biWeekly} onChange={(n) => set("hoursPerMonth", { ...client.hoursPerMonth, biWeekly: n })} />
                  </Row>
                  <Row label="Medical">
                    <NumInput value={client.hoursPerMonth.medical} onChange={(n) => set("hoursPerMonth", { ...client.hoursPerMonth, medical: n })} />
                  </Row>
                  <Row label="One Time (Jan)">
                    <NumInput value={client.hoursPerMonth.oneTimeJan} onChange={(n) => set("hoursPerMonth", { ...client.hoursPerMonth, oneTimeJan: n })} />
                  </Row>
                  <Row label="One Time (Dec)">
                    <NumInput value={client.hoursPerMonth.oneTimeDec} onChange={(n) => set("hoursPerMonth", { ...client.hoursPerMonth, oneTimeDec: n })} />
                  </Row>
                </div>
              </Card>

              <Card title="Programs / Rates">
                <div className="grid gap-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <FieldLabel>CP</FieldLabel>
                      <NumInput value={client.programBuckets.cp} onChange={(n) => set("programBuckets", { ...client.programBuckets, cp: n })} />
                    </div>
                    <div>
                      <FieldLabel>HM</FieldLabel>
                      <NumInput value={client.programBuckets.hm} onChange={(n) => set("programBuckets", { ...client.programBuckets, hm: n })} />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <FieldLabel>PCA Weekly</FieldLabel>
                      <NumInput value={client.programBuckets.pcaWeekly} onChange={(n) => set("programBuckets", { ...client.programBuckets, pcaWeekly: n })} />
                    </div>
                    <div>
                      <FieldLabel>PCA Monthly</FieldLabel>
                      <NumInput value={client.programBuckets.pcaMonthly} onChange={(n) => set("programBuckets", { ...client.programBuckets, pcaMonthly: n })} />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <FieldLabel>PCA BiWeekly</FieldLabel>
                      <NumInput value={client.programBuckets.pcaBiWeekly} onChange={(n) => set("programBuckets", { ...client.programBuckets, pcaBiWeekly: n })} />
                    </div>
                    <div>
                      <FieldLabel>ADC Days</FieldLabel>
                      <NumInput value={client.programBuckets.adcDays} onChange={(n) => set("programBuckets", { ...client.programBuckets, adcDays: n })} />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <FieldLabel>Hourly</FieldLabel>
                      <NumInput value={client.rates.hourly} onChange={(n) => set("rates", { ...client.rates, hourly: n })} step={0.25} />
                    </div>
                    <div>
                      <FieldLabel>Overnight</FieldLabel>
                      <NumInput value={client.rates.overnight} onChange={(n) => set("rates", { ...client.rates, overnight: n })} step={0.25} />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <FieldLabel>Per Diem</FieldLabel>
                      <NumInput value={client.rates.perDiem} onChange={(n) => set("rates", { ...client.rates, perDiem: n })} step={0.25} />
                    </div>
                    <div>
                      <FieldLabel>Sub</FieldLabel>
                      <NumInput value={client.rates.sub} onChange={(n) => set("rates", { ...client.rates, sub: n })} step={0.25} />
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            <div className="grid gap-4 xl:grid-cols-3">
              <Card title="Foster per Week">
                <div className="grid gap-3">
                  {(["fca1", "fca2", "fca3", "fca4", "fcaVn"] as const).map((k) => (
                    <Row key={k} label={k.toUpperCase()}>
                      <NumInput value={client.fosterPerWeek[k]} onChange={(n) => set("fosterPerWeek", { ...client.fosterPerWeek, [k]: n })} />
                    </Row>
                  ))}
                </div>
              </Card>

              <Card title="Respite x Week">
                <div className="grid gap-3">
                  <Row label="Homemaker">
                    <NumInput value={client.respitePerWeek.homemaker} onChange={(n) => set("respitePerWeek", { ...client.respitePerWeek, homemaker: n })} />
                  </Row>
                  <Row label="Companion">
                    <NumInput value={client.respitePerWeek.companion} onChange={(n) => set("respitePerWeek", { ...client.respitePerWeek, companion: n })} />
                  </Row>
                  <Row label="PCA">
                    <NumInput value={client.respitePerWeek.pca} onChange={(n) => set("respitePerWeek", { ...client.respitePerWeek, pca: n })} />
                  </Row>
                  <Row label="PCA 12">
                    <NumInput value={client.respitePerWeek.pca12} onChange={(n) => set("respitePerWeek", { ...client.respitePerWeek, pca12: n })} />
                  </Row>
                  <Row label="PCA 24">
                    <NumInput value={client.respitePerWeek.pca24} onChange={(n) => set("respitePerWeek", { ...client.respitePerWeek, pca24: n })} />
                  </Row>
                </div>
              </Card>

              <Card title="Notes">
                <div className="grid gap-3">
                  <div>
                    <FieldLabel>Notes</FieldLabel>
                    <textarea
                      value={client.notes}
                      onChange={(e) => set("notes", e.target.value)}
                      className="min-h-24 w-full rounded-2xl border border-slate-200 bg-white p-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-200"
                      placeholder="General client notes..."
                    />
                  </div>
                  <div>
                    <FieldLabel>Hours notes</FieldLabel>
                    <textarea
                      value={client.hoursNotes}
                      onChange={(e) => set("hoursNotes", e.target.value)}
                      className="min-h-20 w-full rounded-2xl border border-slate-200 bg-white p-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-200"
                      placeholder="Notes related to hours/programs..."
                    />
                  </div>
                </div>
              </Card>
            </div>

            <div className="rounded-2xl bg-white ring-1 ring-slate-200">
              <div className="flex flex-wrap gap-2 border-b border-slate-100 px-4 py-3">
                {tabs.map((t) => {
                  const active = t === activeTab;
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setActiveTab(t)}
                      className={
                        active
                          ? "h-9 rounded-xl bg-emerald-600 px-3 text-sm font-semibold text-white"
                          : "h-9 rounded-xl bg-white px-3 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50"
                      }
                    >
                      {t}
                    </button>
                  );
                })}
              </div>
              <div className="p-4">
                <TabPanel tab={activeTab} />
              </div>
            </div>

            <div className="flex flex-wrap gap-2 justify-end">
              <ActionButton label="Copy to Appt / T/S" onClick={() => alert("Copy (wire later)")} />
              <ActionButton label="Cancel Appt." onClick={() => alert("Cancel (wire later)")} />
              <ActionButton label="Copy to Vacation" onClick={() => alert("Copy (wire later)")} />
              <ActionButton label="Copy to Reminder" onClick={() => alert("Copy (wire later)")} />
              <ActionButton label="Copy to Service Order" onClick={() => alert("Copy (wire later)")} />
              <ActionButton label="Create Narrative" onClick={() => alert("Create narrative (wire later)")} />
              <ActionButton label="Check Monthly Hours" onClick={() => alert("Check monthly hours (wire later)")} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[1fr_120px] items-center gap-3">
      <div className="text-sm text-slate-700">{label}</div>
      {children}
    </div>
  );
}

function TabPanel({ tab }: { tab: Tab }) {
  const description: Record<Tab, { title: string; body: string }> = {
    Address: { title: "Address", body: "Address details and contact info. (We show a compact version on the left; you can also duplicate it here.)" },
    CCCI: { title: "CCCI", body: "CCCI-related fields/grid goes here." },
    "Assigned Hours": { title: "Assigned Hours", body: "Assigned hours table, approvals, effective dates, etc." },
    "Assigned Extra Hours": { title: "Assigned Extra Hours", body: "Extra hours table and overrides go here." },
    "Weekly Services": { title: "Weekly Services", body: "Weekly service schedule grid/list goes here." },
    "Monthly Services": { title: "Monthly Services", body: "Monthly services grid/list goes here." },
    "Monthly Hours Used": { title: "Monthly Hours Used", body: "Month-to-date usage, totals, validations, warnings." },
    Vacations: { title: "Vacations", body: "Vacation entries and date ranges." },
    Narratives: { title: "Narratives", body: "Narrative notes list + create/edit." },
    "Service Orders": { title: "Service Orders", body: "Service order list, statuses, export/print." },
    "Provider Report": { title: "Provider Report", body: "Provider reporting screen and filters." },
    "Appointments, T/S": { title: "Appointments, T/S", body: "Appointments & timesheets module embed." },
    Reminders: { title: "Reminders", body: "Reminder list + due dates + notifications." },
  };

  return (
    <div className="rounded-2xl bg-slate-50 p-4 ring-1 ring-slate-200">
      <div className="text-sm font-semibold text-slate-900">{description[tab].title}</div>
      <p className="mt-2 text-sm text-slate-600">{description[tab].body}</p>

      <div className="mt-4 rounded-2xl bg-white p-4 ring-1 ring-slate-200">
        <div className="text-sm font-semibold text-slate-900">Coming next</div>
        <ul className="mt-2 list-disc pl-5 text-sm text-slate-600">
          <li>Table view with search/sort/filter</li>
          <li>Add/Edit modal or side drawer</li>
          <li>API hookup (Next.js Route Handlers)</li>
        </ul>
      </div>
    </div>
  );
}
