"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

export default function ClientDetail() {
  const { ssn } = useParams();
  const [client, setClient] = useState<any>(null);

  useEffect(() => {
    fetch(`/api/clients/${ssn}`)
      .then((r) => r.json())
      .then(setClient);
  }, [ssn]);

  if (!client) return <div className="p-6">Loading…</div>;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-semibold">
        {client.FirstName} {client.LastName}
      </h1>
      <pre className="mt-4 bg-slate-100 p-4 rounded">
        {JSON.stringify(client, null, 2)}
      </pre>
    </div>
  );
}
