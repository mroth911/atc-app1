import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

async function findBySSN(ssn: string) {
  // Prefer Client first
  const c1 = await prisma.client.findUnique({ where: { SSN: ssn } });
  if (c1) return { row: c1, source: "Client" as const };

  // ✅ replace prisma.client2 with your actual accessor
  const c2 = await prisma.client2.findUnique({ where: { SSN: ssn } });
  if (c2) return { row: c2, source: "Client2" as const };

  return null;
}

export async function GET(_: Request, { params }: { params: { ssn: string } }) {
  try {
    const found = await findBySSN(params.ssn);
    if (!found) return NextResponse.json({ error: "Not found" }, { status: 404 });

    return NextResponse.json({ ...found.row, _source: found.source });
  } catch (e: any) {
    return NextResponse.json(
      { error: "API failed", details: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request, { params }: { params: { ssn: string } }) {
  try {
    const body = await req.json();
    const source = body?._source; // "Client" | "Client2"

    const data = {
      FirstName: body.FirstName ?? null,
      LastName: body.LastName ?? null,
      Phone: body.Phone ?? null,
      Home: body.Home ?? null,
      Street: body.Street ?? null,
      Apt: body.Apt ?? null,
      Town: body.Town ?? null,
      State: body.State ?? null,
      Zip: body.Zip ?? null,
      Gender: body.Gender ?? null,
      DOB: body.DOB ? new Date(body.DOB) : null,
    };

    if (source === "Client2") {
      // ✅ replace prisma.client2 with your actual accessor
      const updated = await prisma.client2.update({
        where: { SSN: params.ssn },
        data,
      });
      return NextResponse.json({ ...updated, _source: "Client2" });
    }

    // default to Client
    const updated = await prisma.client.update({
      where: { SSN: params.ssn },
      data,
    });
    return NextResponse.json({ ...updated, _source: "Client" });
  } catch (e: any) {
    return NextResponse.json(
      { error: "API failed", details: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}
