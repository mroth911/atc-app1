import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

function pickSSN(c: any) {
  return c.SSN ?? c.Ssn ?? c.ssn ?? null;
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const q = url.searchParams.get("q")?.trim();

    const where = q
      ? {
          OR: [
            { LastName: { contains: q } },
            { FirstName: { contains: q } },
            { SSN: { contains: q } },
          ],
        }
      : undefined;

    // ✅ IMPORTANT: replace prisma.client2 with your actual second model accessor
    const [a, b] = await Promise.all([
      prisma.client.findMany({
        where,
        take: 100,
        orderBy: [{ LastName: "asc" }, { FirstName: "asc" }],
      }),
      prisma.client2.findMany({
        where,
        take: 100,
        orderBy: [{ LastName: "asc" }, { FirstName: "asc" }],
      }),
    ]);

    // Merge + de-dupe by SSN (prefer dbo.Client over dbo.Client2)
    const map = new Map<string, any>();

    for (const row of b) {
      const ssn = pickSSN(row);
      if (!ssn) continue;
      map.set(ssn, { ...row, _source: "Client2" });
    }

    for (const row of a) {
      const ssn = pickSSN(row);
      if (!ssn) continue;
      map.set(ssn, { ...row, _source: "Client" }); // overwrite (prefer Client)
    }

    return NextResponse.json(Array.from(map.values()).slice(0, 200));
  } catch (e: any) {
    return NextResponse.json(
      { error: "API failed", details: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}
